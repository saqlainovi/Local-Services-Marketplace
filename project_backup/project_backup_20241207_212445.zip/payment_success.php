<?php
ob_start();
session_start();
$page_title = "Payment Successful";
include('includes/header.php');
include('includes/navbar.php');
include('dbcon.php');

if (!isset($_SESSION['authenticated'])) {
    header('Location: login.php');
    exit();
}

$payment_id = mysqli_real_escape_string($con, $_GET['id'] ?? '');
$query = "SELECT p.*, pa.name as painter_name, pa.contact_number 
          FROM payments p 
          JOIN painters pa ON p.painter_id = pa.id 
          WHERE p.id = '$payment_id'";
$result = mysqli_query($con, $query);
$payment = mysqli_fetch_assoc($result);
?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-6 mx-auto text-center">
            <div class="card shadow">
                <div class="card-body">
                    <i class="fas fa-check-circle text-success" style="font-size: 64px;"></i>
                    <h3 class="mt-3">Payment Successful!</h3>
                    <p class="text-muted">Your booking has been confirmed</p>
                    
                    <div class="booking-details mt-4 text-start">
                        <p><strong>Painter:</strong> <?php echo $payment['painter_name']; ?></p>
                        <p><strong>Service Date:</strong> <?php echo date('F j, Y', strtotime($payment['booking_date'])); ?></p>
                        <p><strong>Amount Paid:</strong> ৳<?php echo number_format($payment['amount'], 2); ?></p>
                        <p><strong>Contact Number:</strong> <?php echo $payment['contact_number']; ?></p>
                    </div>
                    
                    <div class="mt-4">
                        <a href="index.php" class="btn btn-primary">Back to Home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
include('includes/footer.php');
ob_end_flush();
?>