<?php
session_start();
include('includes/header.php');
include('includes/navbar.php');
include('dbcon.php');

// Get locksmiths list
$query = "SELECT * FROM locksmiths WHERE availability = 1";
$result = mysqli_query($con, $query);
?>

<div class="container mt-4">
    <h2 class="text-center mb-4">Locksmith Services</h2>
    
    <div class="row">
        <?php while($locksmith = mysqli_fetch_assoc($result)): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="<?= isset($locksmith['profile_image']) ? 'uploads/'.$locksmith['profile_image'] : 'assets/img/default-locksmith.jpg' ?>" 
                         class="card-img-top" alt="<?= $locksmith['name'] ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?= $locksmith['name'] ?></h5>
                        <p class="card-text">
                            <i class="fa fa-map-marker"></i> <?= $locksmith['location'] ?><br>
                            <i class="fa fa-briefcase"></i> <?= $locksmith['work_experience'] ?> years experience<br>
                            <i class="fa fa-money"></i> ৳<?= $locksmith['price_per_service'] ?> per service
                        </p>
                        <a href="book_service.php?type=locksmith&id=<?= $locksmith['id'] ?>" class="btn btn-primary">Book Now</a>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<?php include('includes/footer.php'); ?> 