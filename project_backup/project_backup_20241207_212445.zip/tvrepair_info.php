<?php 
session_start();
include('includes/header.php');
include('includes/navbar.php');
include('dbcon.php');

if(isset($_GET['id'])) {
    $technician_id = mysqli_real_escape_string($con, $_GET['id']);
    $query = "SELECT * FROM tv_repair_technicians WHERE id = '$technician_id'";
    $result = mysqli_query($con, $query);
    
    if(mysqli_num_rows($result) > 0) {
        $technician = mysqli_fetch_assoc($result);
?>

<div class="container mt-4">
    <div class="row">
        <!-- Technician Image -->
        <div class="col-md-3">
            <img src="<?= $technician['image'] ?>" class="img-fluid rounded" alt="<?= $technician['name'] ?>">
        </div>

        <!-- Technician Details -->
        <div class="col-md-9">
            <div class="d-flex justify-content-between align-items-start mb-3">
                <h3><?= $technician['name'] ?></h3>
                <span class="badge bg-success">Available Now</span>
            </div>

            <!-- Rating Stars -->
            <div class="d-flex align-items-center mb-3">
                <div class="star-rating me-2">
                    <?php 
                    $rating = $technician['rating'] ?? 0;
                    for($i = 1; $i <= 5; $i++) {
                        if($i <= $rating) {
                            echo '<i class="fa fa-star text-warning"></i>';
                        } else {
                            echo '<i class="fa fa-star-o text-warning"></i>';
                        }
                    }
                    ?>
                </div>
            </div>

            <!-- Other details -->
            <p class="mb-2">
                <i class="fas fa-map-marker-alt text-primary me-2"></i>
                <?= $technician['location'] ?>
            </p>
            <p class="mb-2">
                <i class="fas fa-phone text-primary me-2"></i>
                <?= $technician['contact_number'] ?>
            </p>
            <p class="mb-2">
                <i class="fas fa-envelope text-primary me-2"></i>
                <?= $technician['email'] ?>
            </p>
            <p class="mb-2">
                <i class="fas fa-briefcase text-primary me-2"></i>
                <?= $technician['work_experience'] ?> Years Experience
            </p>
            <p class="mb-2">
                <i class="fas fa-tools text-primary me-2"></i>
                <?= $technician['specialization'] ?>
            </p>
            <p class="mb-3">
                <i class="fas fa-money-bill text-primary me-2"></i>
                ৳<?= number_format($technician['price_per_service'], 2) ?> per service
            </p>

            <!-- Hire Button -->
            <?php if(isset($_SESSION['auth_user'])): ?>
                <a href="payment.php?id=<?= $technician_id ?>&type=tvrepair" class="btn btn-primary">
                    <i class="fas fa-handshake me-2"></i>Hire Now
                </a>
            <?php else: ?>
                <a href="login.php" class="btn btn-primary">
                    <i class="fas fa-sign-in-alt me-2"></i>Login to Hire
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Reviews Section -->
    <!-- (Same as painter_info.php but with appropriate table references) -->
</div>

<?php
    } else {
        echo "<div class='container mt-4'><div class='alert alert-danger'>Technician not found</div></div>";
    }
} else {
    echo "<div class='container mt-4'><div class='alert alert-danger'>Invalid request</div></div>";
}
include('includes/footer.php');
?> 