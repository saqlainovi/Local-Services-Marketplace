<?php
session_start();
include('dbcon.php');

// Get JSON data
$data = json_decode(file_get_contents('php://input'), true);

// Validate user is logged in
if (!isset($_SESSION['authenticated'])) {
    echo json_encode(['success' => false, 'message' => 'User not authenticated']);
    exit();
}

// Get user ID from email
$user_email = $_SESSION['auth_user']['email'];
$user_query = "SELECT id FROM users WHERE email = '$user_email'";
$user_result = mysqli_query($con, $user_query);
$user = mysqli_fetch_assoc($user_result);
$user_id = $user['id'];

$painter_id = mysqli_real_escape_string($con, $data['painter_id']);
$amount = mysqli_real_escape_string($con, $data['amount']);
$payment_intent_id = mysqli_real_escape_string($con, $data['payment_intent_id']);
$booking_date = mysqli_real_escape_string($con, $data['booking_date']);

// Insert payment record
$query = "INSERT INTO payments (user_id, painter_id, amount, payment_intent_id, status, booking_date) 
          VALUES ('$user_id', '$painter_id', '$amount', '$payment_intent_id', 'completed', '$booking_date')";

if (mysqli_query($con, $query)) {
    $payment_id = mysqli_insert_id($con);
    
    // Update painter availability
    mysqli_query($con, "UPDATE painters SET availability = 0 WHERE id = '$painter_id'");
    
    echo json_encode(['success' => true, 'payment_id' => $payment_id]);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error']);
}
?>