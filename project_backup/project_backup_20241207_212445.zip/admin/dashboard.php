<?php
session_start();
include('includes/header.php');
include('includes/navbar.php');
include('../dbcon.php');

// Check if user is logged in and is admin
if(!isset($_SESSION['auth_user']) || $_SESSION['auth_user']['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Get counts for dashboard
$queries = [
    'plumbers' => "SELECT COUNT(*) as count FROM plumbers",
    'electricians' => "SELECT COUNT(*) as count FROM electricians",
    'painters' => "SELECT COUNT(*) as count FROM painters",
    'tv_technicians' => "SELECT COUNT(*) as count FROM tv_technicians",
    'mechanics' => "SELECT COUNT(*) as count FROM mechanics",
    'packers_movers' => "SELECT COUNT(*) as count FROM packers_movers",
    'locksmiths' => "SELECT COUNT(*) as count FROM locksmiths",
    'battery_services' => "SELECT COUNT(*) as count FROM battery_services",
    'users' => "SELECT COUNT(*) as count FROM users WHERE role = 'user'",
    'bookings' => "SELECT COUNT(*) as count FROM bookings",
    'reviews' => "SELECT COUNT(*) as count FROM reviews",
    'earnings' => "SELECT SUM(amount) as total FROM payments WHERE status = 'completed'"
];

$stats = [];
foreach($queries as $key => $query) {
    $result = mysqli_query($con, $query);
    $stats[$key] = mysqli_fetch_assoc($result)[$key === 'earnings' ? 'total' : 'count'] ?? 0;
}
?>

<div class="container-fluid px-4">
    <h1 class="mt-4">Dashboard</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Dashboard</li>
    </ol>

    <!-- Stats Overview -->
    <div class="row">
        <!-- Service Providers -->
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="mb-0"><?= array_sum(array_slice($stats, 0, 8)) ?></h4>
                            <div>Total Service Providers</div>
                        </div>
                        <i class="fas fa-users fa-2x"></i>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="service_providers.php">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>

        <!-- Users -->
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="mb-0"><?= $stats['users'] ?></h4>
                            <div>Registered Users</div>
                        </div>
                        <i class="fas fa-user-circle fa-2x"></i>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="users.php">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>

        <!-- Bookings -->
        <div class="col-xl-3 col-md-6">
            <div class="card bg-warning text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="mb-0"><?= $stats['bookings'] ?></h4>
                            <div>Total Bookings</div>
                        </div>
                        <i class="fas fa-calendar-check fa-2x"></i>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="bookings.php">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>

        <!-- Earnings -->
        <div class="col-xl-3 col-md-6">
            <div class="card bg-info text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="mb-0">৳<?= number_format($stats['earnings'], 2) ?></h4>
                            <div>Total Earnings</div>
                        </div>
                        <i class="fas fa-money-bill-wave fa-2x"></i>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="earnings.php">View Details</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Service Provider Stats -->
    <div class="row">
        <div class="col-xl-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-chart-bar me-1"></i>
                    Service Providers by Category
                </div>
                <div class="card-body">
                    <canvas id="serviceProvidersChart" width="100%" height="40"></canvas>
                </div>
            </div>
        </div>
        <div class="col-xl-6">
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-chart-line me-1"></i>
                    Monthly Bookings
                </div>
                <div class="card-body">
                    <canvas id="bookingsChart" width="100%" height="40"></canvas>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Recent Bookings
        </div>
        <div class="card-body">
            <table id="recentBookingsTable" class="table table-striped">
                <thead>
                    <tr>
                        <th>Booking ID</th>
                        <th>User</th>
                        <th>Service Type</th>
                        <th>Provider</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $recent_bookings_query = "SELECT b.*, u.name as user_name, p.amount 
                                            FROM bookings b 
                                            JOIN users u ON b.user_id = u.id 
                                            JOIN payments p ON b.payment_id = p.id 
                                            ORDER BY b.created_at DESC LIMIT 10";
                    $recent_bookings = mysqli_query($con, $recent_bookings_query);
                    while($booking = mysqli_fetch_assoc($recent_bookings)):
                    ?>
                    <tr>
                        <td>#<?= $booking['id'] ?></td>
                        <td><?= htmlspecialchars($booking['user_name']) ?></td>
                        <td><?= ucfirst($booking['service_type']) ?></td>
                        <td><?= htmlspecialchars($booking['provider_name']) ?></td>
                        <td>৳<?= number_format($booking['amount'], 2) ?></td>
                        <td>
                            <span class="badge bg-<?= $booking['status'] === 'completed' ? 'success' : 
                                                   ($booking['status'] === 'pending' ? 'warning' : 'danger') ?>">
                                <?= ucfirst($booking['status']) ?>
                            </span>
                        </td>
                        <td><?= date('d M Y', strtotime($booking['created_at'])) ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Charts JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js"></script>
<script>
// Service Providers Chart
var ctx = document.getElementById("serviceProvidersChart");
new Chart(ctx, {
    type: "bar",
    data: {
        labels: ["Plumbers", "Electricians", "Painters", "TV Technicians", "Mechanics", "Packers & Movers", "Locksmiths", "Battery Services"],
        datasets: [{
            label: "Number of Providers",
            backgroundColor: "rgba(0, 97, 242, 0.7)",
            borderColor: "rgba(0, 97, 242, 1)",
            data: [
                <?= $stats['plumbers'] ?>,
                <?= $stats['electricians'] ?>,
                <?= $stats['painters'] ?>,
                <?= $stats['tv_technicians'] ?>,
                <?= $stats['mechanics'] ?>,
                <?= $stats['packers_movers'] ?>,
                <?= $stats['locksmiths'] ?>,
                <?= $stats['battery_services'] ?>
            ],
        }],
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});

// Monthly Bookings Chart
// ... (Add monthly bookings chart implementation)
</script>

<?php include('includes/footer.php'); ?> 