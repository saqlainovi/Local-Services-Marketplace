<?php
// Start session only if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<style>
    /* Navbar links and buttons */
    .navbar .nav-link {
        color: white !important;
    }

    /* Dropdown toggle button */
    .navbar .dropdown-toggle {
        color: white !important;
    }

    /* Dropdown menu */
    .navbar .dropdown-menu {
        background-color: #212529;
        border: 1px solid rgba(255,255,255,0.15);
    }

    /* Dropdown items */
    .navbar .dropdown-item {
        color: white !important;
    }

    /* Dropdown item hover */
    .navbar .dropdown-item:hover {
        background-color: rgba(255,255,255,0.1);
        color: white !important;
    }

    /* Dropdown divider */
    .navbar .dropdown-divider {
        border-top: 1px solid rgba(255,255,255,0.15);
    }

    /* Active state */
    .navbar .nav-link.active,
    .navbar .dropdown-item.active {
        color: white !important;
        font-weight: bold;
    }

    /* Hover effects */
    .navbar .nav-link:hover {
        color: rgba(255,255,255,0.8) !important;
    }
</style>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <div class="d-flex align-items-center">
            <img src="img/logo.png" alt="Logo" style="height: 70px; width: auto; margin-right: 10px;">
            <a class="navbar-brand" href="index.php">
                <h1 class="mb-0">Local Service Provider</h1>
            </a>
        </div>

        <form class="d-flex align-items-center" action="search.php" method="GET">
            <div class="input-group" style="width: 300px;">
                <input class="form-control" type="text" name="query" 
                       placeholder="Search services or locations..." 
                       value="<?php echo isset($_GET['query']) ? htmlspecialchars($_GET['query']) : ''; ?>"
                       aria-label="Search">
                <button class="btn btn-outline-success" type="submit">
                    <i class="fa fa-search"></i> Search
                </button>
            </div>
        </form>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                
                
                <li class="nav-item">
                    
                    <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="index.php#browse">services</a>
                </li>

                <?php if (!isset($_SESSION['authenticated'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Registration</a>
                    </li>
                <?php endif; ?>

                <?php if (isset($_SESSION['authenticated'])): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Logout</a>
                    </li>
                    
                    <!-- <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Profile
                        </a>
                       
                       
                       
                        <ul class="dropdown-menu">
                            <li class="nav-item">
                                <a class="dropdown-item" href="Dashbord.php">Dashboard</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="edit_profile.php">Edit Profile</a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="Orders.php">My Orders</a>
                            </li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li>
                                <a class="dropdown-item" href="review.php">Rating</a>
                            </li>
                        </ul>




                    </li> -->
                    <li class="nav-item">
                        <a class="nav-link" href="Dashbord.php">Profile</a>
                    </li>


                    
                <?php endif; ?>

                <li class="nav-item">
                    <a class="nav-link" href="About_us.php">About</a>
                </li>

            </ul>
        </div>
    </div>
</nav>
