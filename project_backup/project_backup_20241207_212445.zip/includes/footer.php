<!-- Footer -->
<footer class="text-center text-lg-start bg-dark text-white">
    <!-- Section: Social media -->
    <section class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
        <!-- Left -->
        <div class="me-5 d-none d-lg-block">
            <span>Get connected with us on social networks:</span>
        </div>
        <!-- Left -->

        <!-- Right -->
        <div>
            <a href="" class="me-4 text-white">
                <i class="fab fa-facebook-f"></i>
            </a>
            <a href="" class="me-4 text-white">
                <i class="fab fa-twitter"></i>
            </a>
            <a href="" class="me-4 text-white">
                <i class="fab fa-google"></i>
            </a>
            <a href="" class="me-4 text-white">
                <i class="fab fa-instagram"></i>
            </a>
            <a href="" class="me-4 text-white">
                <i class="fab fa-linkedin"></i>
            </a>
            <a href="" class="me-4 text-white">
                <i class="fab fa-github"></i>
            </a>
        </div>
        <!-- Right -->
    </section>
    <!-- Section: Social media -->

    <!-- Section: Links -->
    <section class="pt-4">
        <div class="container text-center text-md-start mt-5">
            <!-- Grid row -->
            <div class="row mt-3">
                <!-- Grid column -->
                <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
                    <!-- Content -->
                    <h6 class="text-uppercase fw-bold mb-4">
                        <i class="fas fa-home me-3"></i> Local Service
                    </h6>
                    <p>
                        Your trusted platform for professional Local services. 
                        Quality work, verified professionals, and customer satisfaction guaranteed.
                    </p>
                </div>
                <!-- Grid column -->

                <!-- Grid column -->
                <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
                    <!-- Links -->
                    <h6 class="text-uppercase fw-bold mb-4">
                        Services
                    </h6>
                    <p>
                        <a href="electrician.php" class="text-white text-decoration-none">Electrician</a>
                    </p>
                    <p>
                        <a href="plumber.php" class="text-white text-decoration-none">Plumber</a>
                    </p>
                    <p>
                        <a href="painter.php" class="text-white text-decoration-none">Painter</a>
                    </p>
                    <p>
                        <a href="carpenter.php" class="text-white text-decoration-none">Carpenter</a>
                    </p>
                </div>
                <!-- Grid column -->

                <!-- Grid column -->
                <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
                    <!-- Links -->
                    <h6 class="text-uppercase fw-bold mb-4">
                        Quick links
                    </h6>
                    <p>
                        <a href="about.php" class="text-white text-decoration-none">About Us</a>
                    </p>
                    <p>
                        <a href="services.php" class="text-white text-decoration-none">Services</a>
                    </p>
                    <p>
                        <a href="contact.php" class="text-white text-decoration-none">Contact</a>
                    </p>
                    <p>
                        <a href="help.php" class="text-white text-decoration-none">Help</a>
                    </p>
                </div>
                <!-- Grid column -->

                <!-- Grid column -->
                <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
                    <!-- Links -->
                    <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
                    <p><i class="fas fa-home me-3"></i> Green University of Bangladesh (GUB), Department of Computer Science and Engineering, Batch 212.</p>
                    <p><i class="fas fa-envelope me-3"></i> mdsiyamsaqlainovi@gmail.com</p>
                    <p><i class="fas fa-phone me-3"></i> + 88 017 1234 5678</p>
                    <p><i class="fas fa-print me-3"></i> + 88 016 1234 5678</p>
                </div>
                <!-- Grid column -->
            </div>
            <!-- Grid row -->
        </div>
    </section>
    <!-- Section: Links -->

    <!-- Copyright -->
    <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
        © 2024 Copyright:
        <a class="text-white text-decoration-none fw-bold" href="#">Local_Service_Provider</a>
        | Developed by 
        <span class="text-warning">Md Siyam Saqlain Ovi, Sisi & Yeaz Ussin</span>
    </div>
    <!-- Copyright -->
</footer>
<!-- Footer -->

<style>
footer {
    margin-top: 50px;
}

footer a {
    transition: color 0.3s ease;
}

footer a:hover {
    color: #ffc107 !important;
}

.social-icon {
    width: 35px;
    height: 35px;
    line-height: 35px;
    border-radius: 50%;
    text-align: center;
    display: inline-block;
    background: rgba(255, 255, 255, 0.1);
    margin: 0 5px;
    transition: all 0.3s ease;
}

.social-icon:hover {
    background: #ffc107;
    transform: translateY(-3px);
}

footer h6 {
    position: relative;
    padding-bottom: 12px;
}

footer h6::after {
    content: '';
    position: absolute;
    left: 0;
    bottom: 0;
    width: 50px;
    height: 2px;
    background: #ffc107;
}

@media (max-width: 767.98px) {
    footer h6::after {
        left: 50%;
        transform: translateX(-50%);
    }
}
</style>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>