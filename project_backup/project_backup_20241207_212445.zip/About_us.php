<?php 
$page_title = "About Us";
include('includes/header.php');
include('includes/navbar.php');
?>

<div class="container py-5">
    <!-- Project Overview Section -->
    <div class="row mb-5">
        <div class="col-lg-8 mx-auto text-center">
            <h1 class="display-4 mb-4">Our IDP-2 Project</h1>
            <p class="lead text-muted mb-4">A comprehensive home service provider platform developed as part of our IDP-2 course project at Green University of Bangladesh (GUB), Department of Computer Science and Engineering, Batch 212.</p>
            <div class="d-flex justify-content-center gap-3">
                <a href="#team" class="btn btn-primary px-4">Meet Our Team</a>
                <a href="#features" class="btn btn-outline-primary px-4">Project Features</a>
            </div>
        </div>
    </div>

    <!-- Team Section -->
    <section id="team" class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Our Team Members</h2>
            <div class="row g-4">
                <!-- Team Member 1 -->
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <img src="assets/img/team/siyam.jpg" alt="Md Siyam Saqlain Ovi" 
                                 class="rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                            <h5 class="card-title">Md Siyam Saqlain Ovi</h5>
                            <p class="card-text text-muted">Student ID: 212002082</p>
                            <p class="card-text">BSc in CSE, Batch 212</p>
                            <div class="social-links">
                                <a href="#" class="text-dark me-2"><i class="fab fa-github"></i></a>
                                <a href="#" class="text-primary me-2"><i class="fab fa-linkedin"></i></a>
                                <a href="#" class="text-info"><i class="fab fa-twitter"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Team Member 2 -->
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <img src="assets/img/team/sisi.jpg" alt="Sisi" 
                                 class="rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                            <h5 class="card-title">Sisi</h5>
                            <p class="card-text text-muted">Student ID: [ID Number]</p>
                            <p class="card-text">BSc in CSE, Batch 212</p>
                            <div class="social-links">
                                <a href="#" class="text-dark me-2"><i class="fab fa-github"></i></a>
                                <a href="#" class="text-primary me-2"><i class="fab fa-linkedin"></i></a>
                                <a href="#" class="text-info"><i class="fab fa-twitter"></i></a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Team Member 3 -->
                <div class="col-md-4">
                    <div class="card h-100 border-0 shadow-sm">
                        <div class="card-body text-center">
                            <img src="assets/img/team/yadd.jpg" alt="Yadd Ussin" 
                                 class="rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                            <h5 class="card-title">Yadd Ussin</h5>
                            <p class="card-text text-muted">Student ID: [ID Number]</p>
                            <p class="card-text">BSc in CSE, Batch 212</p>
                            <div class="social-links">
                                <a href="#" class="text-dark me-2"><i class="fab fa-github"></i></a>
                                <a href="#" class="text-primary me-2"><i class="fab fa-linkedin"></i></a>
                                <a href="#" class="text-info"><i class="fab fa-twitter"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Project Features -->
    <section id="features" class="py-5">
        <div class="container">
            <h2 class="text-center mb-5">Project Features</h2>
            <div class="row g-4">
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-users fa-2x text-primary"></i>
                            </div>
                            <h5 class="card-title">User Management</h5>
                            <p class="card-text">Secure authentication system with email verification and role-based access control.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-tools fa-2x text-primary"></i>
                            </div>
                            <h5 class="card-title">Service Booking</h5>
                            <p class="card-text">Easy-to-use service booking system with real-time availability checking.</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-body">
                            <div class="feature-icon mb-3">
                                <i class="fas fa-credit-card fa-2x text-primary"></i>
                            </div>
                            <h5 class="card-title">Secure Payments</h5>
                            <p class="card-text">Integrated payment system using Stripe for secure and reliable transactions.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- Rest of the styling remains the same -->