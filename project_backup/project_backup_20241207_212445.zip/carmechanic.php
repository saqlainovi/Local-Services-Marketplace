<?php
session_start();
include('includes/header.php');
include('includes/navbar.php');
include('dbcon.php');

// Get mechanics list
$query = "SELECT * FROM mechanics WHERE availability = 1";
$result = mysqli_query($con, $query);
?>

<div class="container mt-4">
    <h2 class="text-center mb-4">Car Mechanic Services</h2>
    
    <div class="row">
        <?php while($mechanic = mysqli_fetch_assoc($result)): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="<?= isset($mechanic['profile_image']) ? 'uploads/'.$mechanic['profile_image'] : 'assets/img/default-mechanic.jpg' ?>" 
                         class="card-img-top" alt="<?= $mechanic['name'] ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?= $mechanic['name'] ?></h5>
                        <p class="card-text">
                            <i class="fa fa-map-marker"></i> <?= $mechanic['location'] ?><br>
                            <i class="fa fa-briefcase"></i> <?= $mechanic['work_experience'] ?> years experience<br>
                            <i class="fa fa-money"></i> ৳<?= $mechanic['price_per_hour'] ?> per hour
                        </p>
                        <a href="book_service.php?type=mechanic&id=<?= $mechanic['id'] ?>" class="btn btn-primary">Book Now</a>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<?php include('includes/footer.php'); ?> 