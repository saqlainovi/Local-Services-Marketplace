<?php
session_start();
include('includes/header.php');
include('includes/navbar.php');
include('dbcon.php');

// Get plumbers list
$query = "SELECT * FROM plumbers WHERE availability = 1";
$result = mysqli_query($con, $query);
?>

<div class="container mt-4">
    <h2 class="text-center mb-4">Plumbing Services</h2>
    
    <div class="row">
        <?php while($plumber = mysqli_fetch_assoc($result)): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="<?= isset($plumber['profile_image']) ? 'uploads/'.$plumber['profile_image'] : 'assets/img/default-plumber.jpg' ?>" 
                         class="card-img-top" alt="<?= $plumber['name'] ?>">
                    <div class="card-body">
                        <h5 class="card-title"><?= $plumber['name'] ?></h5>
                        <p class="card-text">
                            <i class="fa fa-map-marker"></i> <?= $plumber['location'] ?><br>
                            <i class="fa fa-briefcase"></i> <?= $plumber['work_experience'] ?> years experience<br>
                            <i class="fa fa-money"></i> ৳<?= $plumber['price_per_service'] ?> per service
                        </p>
                        <a href="plumber_info.php?id=<?= $plumber['id'] ?>" class="btn btn-primary">View Details</a>
                    </div>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<?php include('includes/footer.php'); ?> 