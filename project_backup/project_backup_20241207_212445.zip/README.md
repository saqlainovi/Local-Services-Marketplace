# Project Setup Instructions

1. Install required dependencies:
   ```bash
   composer require phpmailer/phpmailer
   ```

2. Configure email settings:
   - Go to `config/mail_config.php`
   - Update the following settings:
     - SMTP_USERNAME (Your Gmail address)
     - SMTP_PASSWORD (Your Gmail app password)
     - SMTP_FROM_EMAIL (Your Gmail address)
     - SMTP_FROM_NAME (Your name or system name)

3. To get Gmail app password:
   - Go to your Google Account settings
   - Enable 2-Step Verification if not already enabled
   - Go to Security → App passwords
   - Generate a new app password for your application

4. Database setup:
   - Import the database file from `@frank_5.sql`
   - Update database connection settings in `dbcon.php` 