<?php
session_start();
include('includes/header.php');
include('includes/navbar.php');
include('dbcon.php');

if(isset($_GET['id'])) {
    $id = mysqli_real_escape_string($con, $_GET['id']);
    $query = "SELECT * FROM battery_services WHERE id = '$id'";
    $result = mysqli_query($con, $query);

    if(mysqli_num_rows($result) > 0) {
        $provider = mysqli_fetch_assoc($result);
        ?>
        <div class="container mt-4">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <!-- Provider Details -->
                        <div class="col-md-4">
                            <img src="<?php echo isset($provider['image']) ? $provider['image'] : '../img/default-profile.jpg'; ?>" 
                                 class="img-fluid rounded mb-3" 
                                 alt="<?php echo $provider['name']; ?>">
                        </div>
                        <div class="col-md-8">
                            <h3><?php echo $provider['name']; ?></h3>
                            <div class="mb-3">
                                <span class="badge <?php echo $provider['availability'] ? 'bg-success' : 'bg-danger'; ?>">
                                    <?php echo $provider['availability'] ? 'Available' : 'Not Available'; ?>
                                </span>
                                <span class="badge bg-primary"><?php echo $provider['work_experience']; ?> Years Experience</span>
                            </div>
                            <p>
                                <i class="fa fa-map-marker text-danger"></i> <?php echo $provider['location']; ?><br>
                                <i class="fa fa-money text-success"></i> ৳<?php echo $provider['price_per_service']; ?> per service<br>
                                <i class="fa fa-battery-quarter text-info"></i> <?php echo $provider['battery_types']; ?><br>
                                <i class="fa fa-phone text-primary"></i> <?php echo $provider['contact_number']; ?><br>
                                <i class="fa fa-envelope text-secondary"></i> <?php echo $provider['email']; ?>
                            </p>
                        </div>
                    </div>

                    <!-- Reviews Section -->
                    <div class="card mt-4">
                        <div class="card-header">
                            <h5 class="mb-0">Reviews</h5>
                        </div>
                        <div class="card-body">
                            <?php
                            // Updated query to use battery_service_id instead of provider_id
                            $reviews_query = "SELECT r.*, u.name as reviewer_name, r.rating as review_rating, 
                                             r.review_text, r.created_at 
                                             FROM reviews r 
                                             JOIN users u ON r.user_id = u.id 
                                             WHERE r.battery_service_id = '$id' 
                                             ORDER BY r.created_at DESC";
                            
                            $reviews_result = mysqli_query($con, $reviews_query);

                            if($reviews_result && mysqli_num_rows($reviews_result) > 0):
                                while($review = mysqli_fetch_assoc($reviews_result)):
                            ?>
                                <div class="review-card mb-3 p-3 border-bottom">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h6 class="mb-1"><?= htmlspecialchars($review['reviewer_name']) ?></h6>
                                            <div class="star-rating mb-2">
                                                <?php 
                                                for($i = 1; $i <= 5; $i++) {
                                                    if($i <= $review['review_rating']) {
                                                        echo '<i class="fas fa-star text-warning"></i>';
                                                    } else {
                                                        echo '<i class="far fa-star text-warning"></i>';
                                                    }
                                                }
                                                ?>
                                            </div>
                                            <p class="mb-1"><?= htmlspecialchars($review['review_text']) ?></p>
                                        </div>
                                        <small class="text-muted">
                                            <?= date('M d, Y', strtotime($review['created_at'])) ?>
                                        </small>
                                    </div>
                                </div>
                            <?php 
                                endwhile;
                            else:
                            ?>
                                <p class="text-center text-muted my-4">No reviews yet</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Review Form -->
                    <?php if(isset($_SESSION['auth_user'])): ?>
                        <div class="card mt-4">
                            <div class="card-header">
                                <h5 class="mb-0">Write a Review</h5>
                            </div>
                            <div class="card-body">
                                <form action="submit_review.php" method="POST">
                                    <input type="hidden" name="battery_service_id" value="<?= $id ?>">
                                    <input type="hidden" name="service_type" value="battery">
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Rating</label>
                                        <div class="star-rating-input">
                                            <?php for($i = 5; $i >= 1; $i--): ?>
                                                <input type="radio" name="rating" value="<?= $i ?>" id="star<?= $i ?>" required>
                                                <label for="star<?= $i ?>"><i class="far fa-star"></i></label>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label class="form-label">Your Review</label>
                                        <textarea class="form-control" name="review_text" rows="3" required></textarea>
                                    </div>
                                    
                                    <button type="submit" name="submit_review" class="btn btn-primary">
                                        Submit Review
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    } else {
        echo "<div class='container mt-4'><div class='alert alert-danger'>Service provider not found</div></div>";
    }
} else {
    echo "<div class='container mt-4'><div class='alert alert-danger'>Invalid request</div></div>";
}

include('includes/footer.php');
?> 